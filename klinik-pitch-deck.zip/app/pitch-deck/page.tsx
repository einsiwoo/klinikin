import OptimizedPitchDeck from "@/components/optimized-pitch-deck"

export default function PitchDeckPage() {
  return <OptimizedPitchDeck />
}

